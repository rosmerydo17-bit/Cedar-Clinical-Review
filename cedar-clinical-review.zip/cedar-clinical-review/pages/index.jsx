import { useState, useRef, useCallback } from "react";
import Head from "next/head";

const FLAG_SECTIONS = [
  {
    id: "acute_safety",
    label: "Acute Safety & Stabilization",
    color: "#9B2335",
    lightBg: "#FEF5F5",
    border: "#F5C6C6",
    description: "Red Light items per Cedar guide. Any YES requires NP/MD/DON approval before admission.",
    flags: [
      { id: "needs_medical_stabilization", label: "In need of medical stabilization", desc: "Per Cedar guide: patient requires medical stabilization before routine admission can proceed." },
      { id: "current_si_plan", label: "SI with genuine plan and/or intent (current or within past few months)", desc: "Cedar guide red light: SI with genuine plan and/or intent within past few months." },
      { id: "recent_attempt", label: "Suicide attempt within past few months", desc: "Cedar guide red light: suicide attempt within past few months." },
      { id: "serious_self_harm", label: "Serious self-harm requiring hospitalization (past few months)", desc: "Cedar guide red light: serious incident of self-harm within past few months that required hospitalization." },
      { id: "homicidal_history", label: "Any history of homicidal plan/ideations", desc: "Cedar guide red light: any history of homicidal plan or ideations." },
      { id: "active_psychosis", label: "Hallucinations or any form of psychosis (within past year)", desc: "Cedar guide red light: hallucinations or any forms of psychosis within past year." },
      { id: "active_mania", label: "Currently in manic episode (Bipolar 1 diagnosis)", desc: "Cedar guide red light: currently in manic episode if there is a Bipolar 1 diagnosis." },
      { id: "aggressive_behavior", label: "Aggressive behavior / violence", desc: "Cedar guide red light: aggressive behavior or violence." },
    ],
  },
  {
    id: "medical_red_flags",
    label: "Medical Red Flags",
    color: "#7B4A2D",
    lightBg: "#FDF8F4",
    border: "#E8C9A8",
    description: "Red Light medical items per Cedar guide. All require NP/MD/DON approval.",
    flags: [
      { id: "lvad", label: "Life Vest / L-VAD — Immediate Denial", desc: "Cedar guide: Life Vest or L-VAD is an immediate denial. No admission." },
      { id: "trach_vent", label: "Trach / Portable ventilator", desc: "Cedar guide red light medical item." },
      { id: "oxygen_high", label: "Requires oxygen above 5L", desc: "Cedar guide: oxygen must be <5L. Above 5L is a red light." },
      { id: "methadone", label: "Methadone (regardless of dosage)", desc: "Cedar guide red light: methadone regardless of dosage." },
      { id: "iv_antibiotics", label: "IV antibiotics", desc: "Cedar guide red light medical item." },
      { id: "port_pic_line", label: "Port / PICC line access", desc: "Cedar guide red light: port or PICC line access." },
      { id: "pregnant_over_2mo", label: "Pregnant over 2 months (needs OB visit)", desc: "Cedar guide: pregnant clients over 2 months need OB visit before admission. Note: first trimester OK, no DTX from alcohol." },
      { id: "tbi", label: "TBI (traumatic brain injury)", desc: "Cedar guide red light: TBI." },
      { id: "genetic_chronic", label: "Genetic/chronic condition (Down syndrome, Schizoaffective, MS, Autism, Cognitive, Wernicke-Korsakoff)", desc: "Cedar guide red light: genetic or chronic conditions." },
      { id: "recent_hospitalization", label: "Recent hospitalization under 30 days (mental or physical health)", desc: "Cedar guide red light: recent hospitalization <30 days for mental or physical health." },
      { id: "guardianship", label: "Active POA / Guardianship", desc: "Cedar guide red light: active POA or guardianship." },
      { id: "bpd_unmanaged", label: "BPD diagnosis — unmedicated / untreated / unmanaged", desc: "Cedar guide red light: BPD diagnosis that is unmedicated, untreated, or unmanaged." },
      { id: "active_ed", label: "Active eating disorder (behaviors more than 1–2x weekly)", desc: "Cedar guide red light: active ED acting out on behaviors more frequently than 1-2x weekly." },
      { id: "allergy_nature", label: "Allergy to nature", desc: "Cedar guide red light: allergy to nature (Cedar is on 120 acres of forested land)." },
    ],
  },
  {
    id: "program_fit",
    label: "Program Fit & LOC Flags",
    color: "#1E4620",
    lightBg: "#F2F8F2",
    border: "#B8D8BA",
    description: "These items affect LOC recommendation, program appropriateness, and payer review.",
    flags: [
      { id: "casey_law_court", label: "Casey Law / Court ordered to Cedar", desc: "Cedar guide red light: Casey Law or court-ordered admission to Cedar Oaks." },
      { id: "less_than_4days_use", label: "Less than 4 days of continuous use (unless opiate OD <24 hrs)", desc: "Cedar guide red light: <4 days of continuous use — exception for opiate OD within <24 hours." },
      { id: "meth_crack_only", label: "Meth / crack / cocaine only (review LOC and commercial insurance)", desc: "Cedar guide: meth/crack/cocaine-only presentation requires LOC and commercial insurance review." },
      { id: "needs_24hr", label: "Needs 24-hour structure / close observation", desc: "Current symptoms or use pattern support residential or detox rather than lower LOC." },
      { id: "major_functional_impairment", label: "Symptoms causing major functional impairment", desc: "Supports medical necessity for structured program rather than outpatient follow-up." },
      { id: "lower_loc_failed", label: "Lower level of care already insufficient", desc: "Recent failed outpatient, repeated relapse after lower LOC, or unsafe step-down history." },
      { id: "refuses_group", label: "Unwilling / unable to participate in group therapy", desc: "MHDT guidance: refusal or inability to engage in group is an unable-to-admit indicator." },
      { id: "severe_symptoms_group", label: "Severe symptoms block group participation or basic ADLs", desc: "Too disorganized, impaired, or cognitively limited to follow group material or complete basic daily living tasks." },
    ],
  },
  {
    id: "insurance_flags",
    label: "Insurance & Payer Flags",
    color: "#2C5F8F",
    lightBg: "#F0F6FF",
    border: "#B8D0F0",
    description: "Per Cedar guide payer rules. These affect whether admission can proceed and at which LOC.",
    flags: [
      { id: "medicaid_mco", label: "Medicaid / MCO only payer", desc: "Cedar does not accept Medicaid as primary payer for treatment." },
      { id: "tricare", label: "Tricare — NO for time being", desc: "Cedar guide: do not accept Tricare for any admits at this time." },
      { id: "medical_mutual_mhdt", label: "Medical Mutual — direct to PHP/MHDT (never accept)", desc: "Cedar guide: do not accept Medical Mutual for any admits direct to PHP/MHDT LOC, ever." },
      { id: "bcbs_il_res", label: "BCBS IL — requesting RES level", desc: "Cedar guide: BCBS IL — no RES. Possible detox case-by-case, preferred for MHDT only." },
      { id: "vob_not_verified", label: "VOB not yet verified / insurance pending", desc: "Benefits have not been confirmed prior to admission discussion." },
    ],
  },
  {
    id: "yellow_light",
    label: "Yellow-Light Coordination Items",
    color: "#B07800",
    lightBg: "#FFFDF0",
    border: "#F0D899",
    description: "Per Cedar guide: gather as much info as possible — next appt, hospital stays, prescriptions, can they provide their own supplies.",
    flags: [
      { id: "feeding_tube", label: "Feeding tube / ostomy / catheter care", desc: "Cedar guide yellow light: must be able to provide their own care and supplies." },
      { id: "infections_oral_abx", label: "Infections requiring oral antibiotics", desc: "Cedar guide yellow light: coordinate with DON on oral antibiotic management." },
      { id: "wounds", label: "Wounds requiring supplies or offsite appointments", desc: "Cedar guide yellow light: coordinate wound care supply needs and any offsite appointment requirements." },
      { id: "pacemaker", label: "Pacemaker / defibrillator", desc: "Cedar guide yellow light: coordinate with DON." },
      { id: "wheelchair_bariatric", label: "Wheelchair / walker / bariatric >350 lbs / limited ADLs", desc: "Cedar guide yellow light: logistics item, include in admit alert, rooming and staffing awareness." },
    ],
  },
];

const ALL_FLAG_IDS = FLAG_SECTIONS.flatMap((s) => s.flags.map((f) => f.id));

const DISPOSITIONS = {
  approve: { label: "Approve for Admission", color: "#2C6E49", icon: "✅" },
  deny: { label: "Deny — Does Not Meet Criteria", color: "#9B2335", icon: "🚫" },
  stabilize_first: { label: "Stabilize First — Not Ready", color: "#C55A11", icon: "⚠️" },
  escalate: { label: "Escalate — NP/MD/DON Approval Required", color: "#B07800", icon: "📋" },
};

const CEDAR_SYSTEM = `You are the Cedar Clinical Review Studio AI for Cedar Oaks Wellness Center (5778 State Route 350, Oregonia OH 45054). CARF accredited.

FACILITY OVERVIEW:
- DTX (Detox): 10 beds, 4 semi-private. ASAM 3.7. 24-hour admission. 72hr no client phone.
- RES (Residential): 10 male / 10 female, 2 per room. ASAM 3.5. 24-hour admission.
- MHDT (Mental Health Day Treatment): 5 cottages, 4 beds/cottage, max 24 patients. Must admit M-TH 9am-1pm or Friday before 10:30am. $100/week housing fee. M-F 9am-4pm groups plus Saturday.
ALL clients must have a PA (pre-assessment). Any red flags require PA submission for NP/MD/DON approval.

CEDAR RED LIGHT FLAGS (require NP/MD/DON approval before admission):
- Pregnant over 2 months (needs OB visit first); first trimester OK but NO alcohol DTX
- Trach/portable ventilator
- Oxygen must be <5L; above 5L = red light
- SI/HI current or within last 30 days
- TBI
- Genetic/chronic conditions: Down syndrome, Schizoaffective, MS, Autism, Cognitive impairment, Wernicke-Korsakoff
- Active POA/Guardianship
- Life Vest/L-VAD = IMMEDIATE DENIAL, no exceptions
- Casey Law / court ordered to Cedar
- IV antibiotics
- Recent hospitalization <30 days (mental or physical health)
- Aggressive behavior / violence
- Allergy to nature (facility is 120 acres forested land)
- Methadone regardless of dosage
- <4 days continuous use (exception: opiate OD within <24 hours)
- Meth/crack/cocaine only — review LOC and confirm commercial insurance
- Port/PICC line access
- Suicide attempt within past few months
- SI with genuine plan and/or intent within past few months
- Serious self-harm within past few months (required hospitalization)
- Hallucinations or any form of psychosis within past year
- BPD diagnosis unmedicated/untreated/unmanaged
- Active ED (behaviors more than 1-2x weekly)
- Currently in manic episode (Bipolar 1 diagnosis)
- In need of medical stabilization
- Any history of homicidal plan/ideations
- OTO chart (Clinically Concerning List)

CEDAR YELLOW LIGHT FLAGS (coordinate with DON, gather full info):
- Feeding tube/ostomy/catheter care (must self-provide care/supplies)
- Infections — oral antibiotics
- Wounds — supplies/offsite appointments needed
- Bariatric >350 lbs / Wheelchair/walker/limited ADLs
- Pacemaker/defibrillator

CEDAR PAYER RULES:
- NO Medicaid as primary treatment payer
- NO Tricare (suspended for now)
- NO Medical Mutual for any direct PHP/MHDT admits, ever
- BCBS IL: NO RES; possible detox case-by-case; preferred for MHDT only
- Medical Mutual for RES: case-by-case, need $1k/week additional; alert billing 24 hrs in advance
- Private Pay: DTX $10k ($8k min shared); RES $7,500/week; MHDT $6k/week + $100/week housing

DISPOSITION RULES:
- "deny": Life Vest/L-VAD (immediate denial)
- "stabilize_first": Active SI with plan/intent, active psychosis, active mania, needs medical stabilization, recent SA, aggressive behavior
- "escalate": Any other red light flag — requires NP/MD/DON approval before proceeding
- "approve": No red/yellow flags, payer confirmed workable, appropriate LOC identified

LOC GUIDANCE:
- DTX (3.7): withdrawal risk, needs medical monitoring
- RES (3.5): SUD primary, 24hr structure needed, no acute medical barriers
- MHDT (3.3): mental health primary, no active SUD as primary, can do groups M-F
- Lower LOC (PHP/IOP): if manageable without 24hr structure

DOCUMENT RULE: Source 1 = Pre-Assessment. Source 2 = Medical Records. NEVER merge them. Tag each finding with its source.

Return ONLY this raw JSON with no markdown fences:
{"disposition":"approve|deny|stabilize_first|escalate","recommended_loc":"specific Cedar LOC if appropriate, or Not appropriate for Cedar at this time","cedar_appropriate":true,"alternative_loc_recommendation":"If not Cedar-appropriate — specify exactly what level of care and setting this patient needs instead and why. Empty string if Cedar is appropriate.","patient_summary":"3-4 sentence clinical snapshot","pa_summary":"2-3 sentences from pre-assessment only","mr_summary":"2-3 sentences from medical records only or No medical records provided","source_conflicts":"contradictions between sources or empty string","flags":{"needs_medical_stabilization":{"value":"yes|no|uncertain","source":"pa|mr|both|neither","note":"brief note citing source"},"current_si_plan":{"value":"","source":"","note":""},"recent_attempt":{"value":"","source":"","note":""},"serious_self_harm":{"value":"","source":"","note":""},"homicidal_history":{"value":"","source":"","note":""},"active_psychosis":{"value":"","source":"","note":""},"active_mania":{"value":"","source":"","note":""},"aggressive_behavior":{"value":"","source":"","note":""},"lvad":{"value":"","source":"","note":""},"trach_vent":{"value":"","source":"","note":""},"oxygen_high":{"value":"","source":"","note":""},"methadone":{"value":"","source":"","note":""},"iv_antibiotics":{"value":"","source":"","note":""},"port_pic_line":{"value":"","source":"","note":""},"pregnant_over_2mo":{"value":"","source":"","note":""},"tbi":{"value":"","source":"","note":""},"genetic_chronic":{"value":"","source":"","note":""},"recent_hospitalization":{"value":"","source":"","note":""},"guardianship":{"value":"","source":"","note":""},"bpd_unmanaged":{"value":"","source":"","note":""},"active_ed":{"value":"","source":"","note":""},"allergy_nature":{"value":"","source":"","note":""},"casey_law_court":{"value":"","source":"","note":""},"less_than_4days_use":{"value":"","source":"","note":""},"meth_crack_only":{"value":"","source":"","note":""},"needs_24hr":{"value":"","source":"","note":""},"major_functional_impairment":{"value":"","source":"","note":""},"lower_loc_failed":{"value":"","source":"","note":""},"refuses_group":{"value":"","source":"","note":""},"severe_symptoms_group":{"value":"","source":"","note":""},"medicaid_mco":{"value":"","source":"","note":""},"tricare":{"value":"","source":"","note":""},"medical_mutual_mhdt":{"value":"","source":"","note":""},"bcbs_il_res":{"value":"","source":"","note":""},"vob_not_verified":{"value":"","source":"","note":""},"feeding_tube":{"value":"","source":"","note":""},"infections_oral_abx":{"value":"","source":"","note":""},"wounds":{"value":"","source":"","note":""},"pacemaker":{"value":"","source":"","note":""},"wheelchair_bariatric":{"value":"","source":"","note":""}},"section_rationales":{"acute_safety":"2-3 sentences","medical_red_flags":"2-3 sentences","program_fit":"2-3 sentences","insurance_flags":"1-2 sentences","yellow_light":"1-2 sentences"},"clinician_notes":"2-3 sentences for the approving clinician or DON","information_gaps":["array of specific missing info"]}`;

const toBase64 = (file) =>
  new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result.split(",")[1]);
    r.onerror = rej;
    r.readAsDataURL(file);
  });

const fmtSize = (b) =>
  b < 1048576 ? `${(b / 1024).toFixed(0)} KB` : `${(b / 1048576).toFixed(1)} MB`;

const valueColor = (v) => ({ yes: "#9B2335", no: "#2C6E49", uncertain: "#B07800" }[v] || "#AAAAAA");
const valueLabel = (v) => ({ yes: "YES", no: "NO", uncertain: "UNCERTAIN" }[v] || "WAITING");

function UploadZone({ label, sublabel, color, icon, files, onAdd, onRemove }) {
  const ref = useRef(null);
  const [drag, setDrag] = useState(false);
  const handleDrop = useCallback(async (e) => { e.preventDefault(); setDrag(false); onAdd(Array.from(e.dataTransfer.files)); }, [onAdd]);

  return (
    <div style={{ flex: 1, minWidth: 240 }}>
      <div style={{ fontSize: "11px", fontWeight: "700", color, textTransform: "uppercase", letterSpacing: "1.5px", marginBottom: "5px" }}>{icon} {label}</div>
      {sublabel && <div style={{ fontSize: "11px", color: "#999", marginBottom: "8px", lineHeight: "1.4" }}>{sublabel}</div>}
      <div onClick={() => ref.current?.click()} onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={handleDrop}
        style={{ border: `2px dashed ${drag ? color : "#C8BDB3"}`, borderRadius: "10px", padding: "18px 14px", textAlign: "center", cursor: "pointer", background: drag ? `${color}08` : "#FAFAF8", transition: "all 0.15s" }}>
        <div style={{ fontSize: "22px", marginBottom: "4px" }}>{files.length ? "📎" : "+"}</div>
        <div style={{ fontSize: "12px", color: "#888" }}>{files.length ? `${files.length} file${files.length > 1 ? "s" : ""} loaded` : "Click or drag to upload"}</div>
        <div style={{ fontSize: "10px", color: "#BBB", marginTop: "2px" }}>PDF · JPG · PNG</div>
      </div>
      <input ref={ref} type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.webp" style={{ display: "none" }} onChange={(e) => { onAdd(Array.from(e.target.files)); e.target.value = ""; }} />
      {files.map((f) => (
        <div key={f.id} style={{ display: "flex", alignItems: "center", gap: "7px", background: "#FFF", border: "1px solid #E0D8D0", borderRadius: "7px", padding: "7px 10px", marginTop: "6px" }}>
          <span>{f.name.endsWith(".pdf") ? "📄" : "🖼️"}</span>
          <span style={{ flex: 1, fontSize: "11px", color: "#444", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{f.name}</span>
          <span style={{ fontSize: "10px", color: "#BBB", flexShrink: 0 }}>{fmtSize(f.size)}</span>
          <button onClick={(e) => { e.stopPropagation(); onRemove(f.id); }} style={{ background: "none", border: "none", color: "#CCC", cursor: "pointer", fontSize: "16px", lineHeight: 1, padding: 0 }}>×</button>
        </div>
      ))}
    </div>
  );
}

function FlagCard({ flag, sectionColor, sectionBorder, aiData, override, onOverride }) {
  const effectiveValue = override !== "auto" ? override : aiData?.value;
  const isOverridden = override !== "auto";
  return (
    <div style={{ background: "#FFF", border: `1px solid ${effectiveValue === "yes" ? sectionBorder : "#EAE4DC"}`, borderLeft: `4px solid ${effectiveValue === "yes" ? sectionColor : effectiveValue === "no" ? "#2C6E49" : "#DDD"}`, borderRadius: "8px", padding: "13px 15px", marginBottom: "8px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "10px", marginBottom: "6px" }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: "13px", fontWeight: "700", color: "#1A1A1A", marginBottom: "2px" }}>{flag.label}</div>
          <div style={{ fontSize: "11px", color: "#999", lineHeight: "1.4" }}>{flag.desc}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "3px", flexShrink: 0 }}>
          <span style={{ background: valueColor(effectiveValue), color: "#FFF", fontSize: "10px", fontWeight: "700", padding: "2px 10px", borderRadius: "20px" }}>{valueLabel(effectiveValue)}</span>
          {isOverridden && <span style={{ fontSize: "9px", color: "#B07800", fontWeight: "600" }}>MANUAL OVERRIDE</span>}
          {!isOverridden && aiData?.source && aiData.source !== "neither" && (
            <span style={{ background: aiData.source === "pa" ? "#2C5F8F" : aiData.source === "mr" ? "#6B3D8A" : "#2C6E49", color: "#FFF", fontSize: "9px", fontWeight: "600", padding: "1px 7px", borderRadius: "10px" }}>
              {aiData.source === "pa" ? "PA" : aiData.source === "mr" ? "MR" : "PA+MR"}
            </span>
          )}
        </div>
      </div>
      <div style={{ fontSize: "11px", color: aiData?.note ? "#555" : "#AAA", fontStyle: aiData?.note ? "normal" : "italic", background: "#F9F5F0", borderRadius: "5px", padding: "7px 10px", marginBottom: "8px", lineHeight: "1.5" }}>
        {aiData?.note || "Waiting on documentation — upload readable source material to auto-fill."}
        {aiData?.note && <span style={{ fontSize: "10px", color: "#BBB", marginLeft: "6px" }}>Source: {aiData.source === "pa" ? "pre-assessment" : aiData.source === "mr" ? "medical records" : aiData.source === "both" ? "both" : "not found"}</span>}
      </div>
      <div style={{ display: "flex", gap: "5px", alignItems: "center" }}>
        {["yes", "no", "auto"].map((v) => (
          <button key={v} onClick={() => onOverride(flag.id, v)} style={{ padding: "4px 12px", fontSize: "11px", fontWeight: "600", borderRadius: "5px", cursor: "pointer", border: `1px solid ${override === v ? sectionColor : "#DDD"}`, background: override === v ? sectionColor : "#FFF", color: override === v ? "#FFF" : "#888", textTransform: "uppercase", fontFamily: "inherit" }}>
            {v === "auto" ? "Auto" : v}
          </button>
        ))}
        <span style={{ fontSize: "10px", color: "#CCC", marginLeft: "4px" }}>Override only</span>
      </div>
    </div>
  );
}

export default function CedarClinicalReviewStudio() {
  const [homeReferral, setHomeReferral] = useState(false);
  const [clientName, setClientName] = useState("");
  const [age, setAge] = useState("");
  const [facility, setFacility] = useState("");
  const [presentation, setPresentation] = useState("Still clarifying");
  const [requestedLoc, setRequestedLoc] = useState("Undecided / need LOC guidance");
  const [insurance, setInsurance] = useState("Unknown / pending VOB");
  const [reviewer, setReviewer] = useState("");
  const [paNotes, setPaNotes] = useState("");
  const [mrNotes, setMrNotes] = useState("");
  const [paFiles, setPaFiles] = useState([]);
  const [mrFiles, setMrFiles] = useState([]);
  const [overrides, setOverrides] = useState(() => Object.fromEntries(ALL_FLAG_IDS.map((id) => [id, "auto"])));
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [tab, setTab] = useState("intake");

  const addFiles = async (src, rawFiles) => {
    const processed = await Promise.all(rawFiles.map(async (f) => ({ id: `${Date.now()}-${Math.random()}`, name: f.name, size: f.size, mediaType: f.type || "application/octet-stream", base64: await toBase64(f) })));
    if (src === "pa") setPaFiles((p) => [...p, ...processed]);
    else setMrFiles((p) => [...p, ...processed]);
  };

  const removeFile = (src, id) => {
    if (src === "pa") setPaFiles((p) => p.filter((f) => f.id !== id));
    else setMrFiles((p) => p.filter((f) => f.id !== id));
  };

  const pushFiles = (content, files, label) => {
    files.forEach((f, i) => {
      content.push({ type: "text", text: `\n-- ${label} FILE ${i + 1}/${files.length}: "${f.name}" --` });
      const isPDF = f.mediaType === "application/pdf" || f.name.toLowerCase().endsWith(".pdf");
      const isImg = f.mediaType.startsWith("image/") || /\.(jpg|jpeg|png|gif|webp)$/i.test(f.name);
      if (isPDF) content.push({ type: "document", source: { type: "base64", media_type: "application/pdf", data: f.base64 } });
      else if (isImg) content.push({ type: "image", source: { type: "base64", media_type: f.mediaType.startsWith("image/") ? f.mediaType : "image/jpeg", data: f.base64 } });
      else content.push({ type: "text", text: `[Not readable: ${f.name}]` });
      content.push({ type: "text", text: `-- END ${label} FILE ${i + 1} --` });
    });
  };

  const runAnalysis = async () => {
    setIsAnalyzing(true); setError(null); setResult(null);
    setStatusMsg("Building document package...");
    try {
      const content = [];
      content.push({ type: "text", text: `CEDAR OAKS CASE\nPatient: ${clientName || "Not provided"} | Age: ${age || "N/A"} | ${homeReferral ? "Home referral (PA-only)" : `Facility: ${facility || "Not provided"}`}\nPresentation: ${presentation} | Requested LOC: ${requestedLoc} | Insurance: ${insurance} | Reviewer: ${reviewer || "N/A"}` });

      content.push({ type: "text", text: `\n${"=".repeat(50)}\nSOURCE 1 — ADMISSIONS PRE-ASSESSMENT\nAll findings from this section = Source 1 (PA). Do not attribute to Source 2.\n${"=".repeat(50)}` });
      if (!paFiles.length && !paNotes.trim()) content.push({ type: "text", text: "[No pre-assessment provided.]" });
      pushFiles(content, paFiles, "PRE-ASSESSMENT");
      if (paNotes.trim()) content.push({ type: "text", text: `\n-- PA NOTES --\n${paNotes.trim()}\n-- END --` });
      content.push({ type: "text", text: `${"=".repeat(50)}\nEND SOURCE 1\n${"=".repeat(50)}` });

      content.push({ type: "text", text: `\n${"=".repeat(50)}\nSOURCE 2 — OUTSIDE MEDICAL RECORDS\nAll findings from this section = Source 2 (MR). Do not attribute to Source 1.\n${"=".repeat(50)}` });
      if (!mrFiles.length && !mrNotes.trim()) content.push({ type: "text", text: homeReferral ? "[Home referral — no MRs required.]" : "[No medical records provided — note as information gap.]" });
      pushFiles(content, mrFiles, "MEDICAL RECORD");
      if (mrNotes.trim()) content.push({ type: "text", text: `\n-- MR NOTES --\n${mrNotes.trim()}\n-- END --` });
      content.push({ type: "text", text: `${"=".repeat(50)}\nEND SOURCE 2\n${"=".repeat(50)}` });
      content.push({ type: "text", text: "\nGenerate the Cedar clinical review JSON now. Return ONLY raw valid JSON — no markdown, no preamble." });

      setStatusMsg("Running Cedar AI analysis...");

      // ── Key difference from artifact version: calls /api/analyze instead of Anthropic directly
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ system: CEDAR_SYSTEM, messages: [{ role: "user", content }], max_tokens: 8000 }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `HTTP ${res.status}`);
      }

      setStatusMsg("Parsing results...");
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      const raw = (data.content || []).map((c) => c.text || "").join("");
      const start = raw.indexOf("{");
      if (start === -1) throw new Error("No JSON in response — try typed notes instead of file upload.");
      let jsonStr = raw.slice(start);

      let parsed;
      try { parsed = JSON.parse(jsonStr); } catch {
        const end = jsonStr.lastIndexOf("}");
        if (end > 0) try { parsed = JSON.parse(jsonStr.slice(0, end + 1)); } catch {}
        if (!parsed) {
          try {
            let s = jsonStr.replace(/,?\s*"[^"]*"\s*:\s*"[^"]*$/, "").replace(/,?\s*"[^"]*"\s*:\s*$/, "").replace(/,\s*$/, "");
            let opens = 0;
            for (const ch of s) { if (ch === "{" || ch === "[") opens++; if (ch === "}" || ch === "]") opens--; }
            let close = "";
            for (let i = 0; i < Math.abs(opens); i++) close += opens > 0 ? "}" : "]";
            parsed = JSON.parse(s + close);
          } catch {}
        }
        if (!parsed) throw new Error("Response was cut off — try fewer files or paste text into typed notes.");
      }

      setResult(parsed);
      setTab("flags");
    } catch (err) {
      setError(err.message);
    } finally { setIsAnalyzing(false); setStatusMsg(""); }
  };

  const ef = (id) => {
    const ov = overrides[id];
    const ai = result?.flags?.[id];
    if (ov !== "auto") return { value: ov, source: null, note: "Manual override by reviewer." };
    return ai || { value: undefined, source: null, note: null };
  };

  const finalDisp = (() => {
    if (!result) return null;
    if (ef("lvad").value === "yes") return "deny";
    const stabilize = ["current_si_plan", "recent_attempt", "active_psychosis", "active_mania", "needs_medical_stabilization", "aggressive_behavior"];
    for (const id of stabilize) if (ef(id).value === "yes") return "stabilize_first";
    const escalate = ["trach_vent", "oxygen_high", "methadone", "iv_antibiotics", "port_pic_line", "pregnant_over_2mo", "tbi", "genetic_chronic", "recent_hospitalization", "guardianship", "bpd_unmanaged", "active_ed", "allergy_nature", "casey_law_court", "less_than_4days_use", "meth_crack_only", "homicidal_history", "serious_self_harm"];
    for (const id of escalate) if (ef(id).value === "yes") return "escalate";
    return result.disposition;
  })();

  const dispInfo = finalDisp ? DISPOSITIONS[finalDisp] : null;
  const hasContent = paFiles.length > 0 || mrFiles.length > 0 || paNotes.trim() || mrNotes.trim();
  const inputSt = { width: "100%", background: "#F8F4EF", border: "1px solid #DDD5C8", borderRadius: "7px", padding: "8px 12px", fontSize: "13px", color: "#1A1A1A", fontFamily: "inherit", boxSizing: "border-box", outline: "none" };
  const lbl = { display: "block", fontSize: "10px", fontWeight: "700", color: "#888", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "4px" };
  const sHdr = { fontSize: "10px", color: "#7B4A2D", fontWeight: "700", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "14px" };

  return (
    <>
      <Head>
        <title>Cedar Clinical Review Studio</title>
        <meta name="description" content="Cedar Oaks Wellness Center — Admissions Clinical Review" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div style={{ fontFamily: "'Palatino Linotype', Georgia, serif", background: "#F3EDE4", minHeight: "100vh", color: "#1A1A1A" }}>
        {/* Header */}
        <div style={{ background: "linear-gradient(135deg, #1A3C1C 0%, #2C5F2E 60%, #1E4A20 100%)", padding: "16px 28px 0", boxShadow: "0 4px 20px rgba(0,0,0,0.25)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", paddingBottom: "12px", gap: "12px", flexWrap: "wrap" }}>
            <div>
              <div style={{ fontSize: "10px", color: "#7CC47E", letterSpacing: "3px", textTransform: "uppercase", marginBottom: "3px" }}>Cedar Oaks Wellness Center · Admissions</div>
              <div style={{ fontSize: "21px", color: "#FFF", fontWeight: "700" }}>Cedar Clinical Review Studio</div>
              <div style={{ fontSize: "11px", color: "#7CC47E", marginTop: "2px" }}>Use the pre-assessment and outside records to draft the Cedar decision</div>
            </div>
            {dispInfo && (
              <div style={{ background: dispInfo.color, color: "#FFF", borderRadius: "8px", padding: "8px 18px", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center", gap: "7px" }}>
                {dispInfo.icon} {dispInfo.label}
              </div>
            )}
          </div>
          <div style={{ display: "flex", gap: "3px" }}>
            {[{ id: "intake", label: "Case Intake" }, { id: "flags", label: "Cedar Review" }, { id: "report", label: "Decision Draft" }].map(({ id, label }) => (
              <button key={id} onClick={() => setTab(id)} style={{ background: tab === id ? "#F3EDE4" : "transparent", border: "none", color: tab === id ? "#2C5F2E" : "#7CC47E", padding: "8px 20px", fontSize: "12px", fontWeight: "600", cursor: "pointer", borderRadius: "6px 6px 0 0", fontFamily: "inherit" }}>{label}</button>
            ))}
          </div>
        </div>

        <div style={{ padding: "22px 28px", maxWidth: "1100px", margin: "0 auto" }}>
          {tab === "intake" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              <div style={{ background: "#FFF8F0", border: "1px solid #E8C9A8", borderRadius: "9px", padding: "12px 16px", fontSize: "12px", color: "#7B4A2D", lineHeight: "1.6" }}>
                <strong>Decision support only.</strong> This draft uses Cedar training criteria (2025 guide) to organize records, surface risk flags, and propose a disposition. Does not replace licensed clinician judgment, NP/MD/DON approval, utilization review, or final admission authority.
              </div>

              <div onClick={() => setHomeReferral(v => !v)} style={{ background: homeReferral ? "#F0FEF4" : "#FFF", border: `1px solid ${homeReferral ? "#B8D8BA" : "#DDD5C8"}`, borderRadius: "9px", padding: "13px 18px", display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }}>
                <div>
                  <div style={{ fontSize: "13px", fontWeight: "700" }}>Coming from home / PA-only referral</div>
                  <div style={{ fontSize: "11px", color: "#999", marginTop: "2px" }}>Turn on when the client is not stepping down from a facility. Outside records stay optional.</div>
                </div>
                <div style={{ width: "44px", height: "24px", background: homeReferral ? "#2C5F2E" : "#CCC", borderRadius: "12px", position: "relative", transition: "background 0.2s", flexShrink: 0 }}>
                  <div style={{ width: "18px", height: "18px", background: "#FFF", borderRadius: "50%", position: "absolute", top: "3px", left: homeReferral ? "23px" : "3px", transition: "left 0.2s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
                </div>
              </div>

              <div style={{ background: "#FFF", borderRadius: "10px", padding: "18px 20px", border: "1px solid #DDD5C8" }}>
                <div style={sHdr}>Client Information</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "12px" }}>
                  <div><label style={lbl}>Client name</label><input value={clientName} onChange={e => setClientName(e.target.value)} placeholder="Jane Doe" style={inputSt} /></div>
                  <div><label style={lbl}>Age</label><input value={age} onChange={e => setAge(e.target.value)} placeholder="34" style={inputSt} /></div>
                  <div><label style={lbl}>Reviewer</label><input value={reviewer} onChange={e => setReviewer(e.target.value)} placeholder="Admissions reviewer" style={inputSt} /></div>
                </div>
                {!homeReferral && (<div style={{ marginTop: "12px" }}><label style={lbl}>Current facility</label><input value={facility} onChange={e => setFacility(e.target.value)} placeholder="Sending facility or hospital" style={inputSt} /></div>)}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "12px", marginTop: "12px" }}>
                  <div>
                    <label style={lbl}>Presentation</label>
                    <select value={presentation} onChange={e => setPresentation(e.target.value)} style={{ ...inputSt, cursor: "pointer" }}>
                      {["Still clarifying","Substance Use — Alcohol","Substance Use — Opioids","Substance Use — Stimulants","Substance Use — Poly-substance","Meth/Crack/Cocaine Only","Mental Health — Depression / Anxiety","Mental Health — Trauma / PTSD","Mental Health — Mood Disorder","Dual Diagnosis — SUD + MH","Other"].map(o => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={lbl}>Requested LOC</label>
                    <select value={requestedLoc} onChange={e => setRequestedLoc(e.target.value)} style={{ ...inputSt, cursor: "pointer" }}>
                      {["Undecided / need LOC guidance","Detox — 3.7","Residential — 3.5","MHDT — Mental Health Day Treatment","PHP (2.5)","IOP (2.1)","Outpatient (1.0)"].map(o => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={lbl}>Insurance</label>
                    <select value={insurance} onChange={e => setInsurance(e.target.value)} style={{ ...inputSt, cursor: "pointer" }}>
                      {["Unknown / pending VOB","Commercial Insurance","Self Pay","Scholarship"].map(o => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              <div style={{ background: "#FFF", borderRadius: "10px", padding: "18px 20px", border: "1px solid #DDD5C8" }}>
                <div style={sHdr}>Upload the Two Decision Sources</div>
                <div style={{ fontSize: "11px", color: "#AAA", marginBottom: "14px" }}>Each source is read separately — findings are tagged PA or MR so you can see exactly what came from where.</div>
                <div style={{ display: "flex", gap: "18px", flexWrap: "wrap" }}>
                  <UploadZone label="Admissions Phone Pre-Assessment" icon="📞" color="#2C5F8F" sublabel="Upload the phone pre-assessment, call transcript, intake form, or typed admissions notes." files={paFiles} onAdd={(f) => addFiles("pa", f)} onRemove={(id) => removeFile("pa", id)} />
                  <UploadZone label={homeReferral ? "Outside Medical Records (Optional)" : "Outside Facility Medical Records"} icon="🏥" color="#6B3D8A" sublabel="Upload referral packets, hospital records, MARs, discharge notes, labs, or supporting records." files={mrFiles} onAdd={(f) => addFiles("mr", f)} onRemove={(id) => removeFile("mr", id)} />
                </div>
              </div>

              <div style={{ background: "#FFF", borderRadius: "10px", padding: "18px 20px", border: "1px solid #DDD5C8" }}>
                <div style={sHdr}>Typed Notes (Optional)</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                  <div><label style={{ ...lbl, color: "#2C5F8F" }}>📞 Pre-Assessment Notes</label><textarea value={paNotes} onChange={e => setPaNotes(e.target.value)} placeholder="Paste admissions phone pre-assessment responses..." rows={4} style={{ ...inputSt, resize: "vertical" }} /></div>
                  <div><label style={{ ...lbl, color: "#6B3D8A" }}>🏥 Medical Record Notes</label><textarea value={mrNotes} onChange={e => setMrNotes(e.target.value)} placeholder="Paste outside facility record details..." rows={4} style={{ ...inputSt, resize: "vertical" }} /></div>
                </div>
              </div>

              <button onClick={runAnalysis} disabled={isAnalyzing || !hasContent} style={{ background: !hasContent ? "#C8BDB3" : "#7B4A2D", color: "#FFF", border: "none", borderRadius: "10px", padding: "15px", fontSize: "15px", fontWeight: "700", cursor: !hasContent ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: "10px", fontFamily: "inherit" }}>
                {isAnalyzing ? (<><span style={{ display: "inline-block", width: "18px", height: "18px", border: "3px solid rgba(255,255,255,0.3)", borderTopColor: "#FFF", borderRadius: "50%", animation: "spin 0.75s linear infinite" }} />{statusMsg}</>) : "🏥  Analyze Case"}
              </button>

              {error && (
                <div style={{ background: "#FEF0F0", border: "1px solid #F5C6C6", borderRadius: "8px", padding: "13px 18px", color: "#9B2335", fontSize: "13px" }}>
                  ⚠️ <strong>Error:</strong> {error}
                  <div style={{ fontSize: "11px", color: "#C55", marginTop: "6px" }}>Tip: if files won&apos;t process, paste the document text into the typed notes fields above — that always works.</div>
                </div>
              )}
            </div>
          )}

          {tab === "flags" && (
            <div>
              {result && (
                <div style={{ marginBottom: "18px", display: "flex", flexDirection: "column", gap: "10px" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                    {[{ label: "📞 From Pre-Assessment", text: result.pa_summary, color: "#2C5F8F", bg: "#F0F6FF" }, { label: "🏥 From Medical Records", text: result.mr_summary, color: "#6B3D8A", bg: "#F8F0FF" }].map(({ label, text, color, bg }) => (
                      <div key={label} style={{ background: bg, border: `1px solid ${color}30`, borderRadius: "9px", padding: "13px 16px" }}>
                        <div style={{ fontSize: "10px", fontWeight: "700", color, marginBottom: "6px", textTransform: "uppercase", letterSpacing: "1px" }}>{label}</div>
                        <div style={{ fontSize: "12px", color: "#444", lineHeight: "1.6" }}>{text}</div>
                      </div>
                    ))}
                  </div>
                  {result.source_conflicts && (<div style={{ background: "#FFFBF0", border: "1px solid #F0D899", borderRadius: "8px", padding: "11px 16px", fontSize: "12px", color: "#7D5A00" }}>⚠️ <strong>Source conflict:</strong> {result.source_conflicts}</div>)}
                </div>
              )}
              {!result && (
                <div style={{ textAlign: "center", padding: "60px 20px", color: "#AAA" }}>
                  <div style={{ fontSize: "44px", marginBottom: "12px" }}>🚩</div>
                  <div style={{ fontSize: "15px", fontWeight: "600", color: "#777", marginBottom: "6px" }}>Ready when your files are</div>
                  <div style={{ fontSize: "13px" }}>Upload documents on Case Intake and run the analysis.</div>
                </div>
              )}
              {FLAG_SECTIONS.map((section) => (
                <div key={section.id} style={{ marginBottom: "22px" }}>
                  <div style={{ background: section.color, color: "#FFF", borderRadius: "8px 8px 0 0", padding: "11px 18px", display: "flex", alignItems: "center", gap: "10px" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: "14px", fontWeight: "700" }}>{section.label}</div>
                      <div style={{ fontSize: "11px", opacity: 0.8, marginTop: "2px" }}>{section.description}</div>
                    </div>
                    {result && (<div style={{ background: "rgba(255,255,255,0.18)", borderRadius: "6px", padding: "4px 12px", fontSize: "11px", fontWeight: "700", flexShrink: 0 }}>{section.flags.filter((f) => ef(f.id).value === "yes").length} YES</div>)}
                  </div>
                  <div style={{ background: section.lightBg, border: `1px solid ${section.border}`, borderTop: "none", borderRadius: "0 0 8px 8px", padding: "14px" }}>
                    <div style={{ fontSize: "11px", color: "#999", marginBottom: "10px", fontStyle: "italic" }}>Cards auto-fill from source documents when readable. Use the buttons only to manually override.</div>
                    {section.flags.map((flag) => (<FlagCard key={flag.id} flag={flag} sectionColor={section.color} sectionBorder={section.border} aiData={result?.flags?.[flag.id]} override={overrides[flag.id]} onOverride={(id, v) => setOverrides(p => ({ ...p, [id]: v }))} />))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "report" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {!result ? (
                <div style={{ textAlign: "center", padding: "60px 20px", color: "#AAA" }}>
                  <div style={{ fontSize: "44px", marginBottom: "12px" }}>📄</div>
                  <div style={{ fontSize: "15px", fontWeight: "600", color: "#777", marginBottom: "6px" }}>No draft yet</div>
                  <div style={{ fontSize: "13px" }}>Run the analysis on the Case Intake tab first.</div>
                </div>
              ) : (
                <>
                  {dispInfo && (
                    <div style={{ background: `linear-gradient(135deg, ${dispInfo.color} 0%, ${dispInfo.color}CC 100%)`, borderRadius: "12px", padding: "20px 26px", color: "#FFF" }}>
                      <div style={{ fontSize: "10px", letterSpacing: "3px", textTransform: "uppercase", opacity: 0.8, marginBottom: "4px" }}>Cedar Clinical Review — Disposition Draft</div>
                      <div style={{ fontSize: "24px", fontWeight: "700", marginBottom: "7px" }}>{dispInfo.icon} {dispInfo.label}</div>
                      <div style={{ fontSize: "14px", opacity: 0.9 }}><strong>Recommended LOC:</strong> {result.recommended_loc}</div>
                      {clientName && <div style={{ fontSize: "12px", opacity: 0.75, marginTop: "3px" }}>Patient: {clientName}{age ? ` · Age ${age}` : ""}{insurance ? ` · ${insurance}` : ""}</div>}
                    </div>
                  )}
                  {result.alternative_loc_recommendation && (
                    <div style={{ background: "linear-gradient(135deg, #1A3C1C 0%, #2C5F2E 100%)", borderRadius: "10px", padding: "18px 22px", color: "#FFF", display: "flex", gap: "16px", alignItems: "flex-start" }}>
                      <div style={{ fontSize: "26px", flexShrink: 0 }}>🔀</div>
                      <div>
                        <div style={{ fontSize: "10px", letterSpacing: "2.5px", textTransform: "uppercase", opacity: 0.75, marginBottom: "4px" }}>If Not Cedar — Recommended Referral</div>
                        <div style={{ fontSize: "15px", fontWeight: "700", marginBottom: "7px" }}>Where This Patient Should Go Instead</div>
                        <div style={{ fontSize: "13px", opacity: 0.92, lineHeight: "1.7" }}>{result.alternative_loc_recommendation}</div>
                      </div>
                    </div>
                  )}
                  <div style={{ background: "#FFF", borderRadius: "10px", padding: "18px 20px", border: "1px solid #DDD5C8" }}>
                    <div style={sHdr}>Clinical Summary</div>
                    <div style={{ fontSize: "13px", lineHeight: "1.75", color: "#333" }}>{result.patient_summary}</div>
                  </div>
                  <div style={{ background: "#FFF", borderRadius: "10px", padding: "18px 20px", border: "1px solid #DDD5C8" }}>
                    <div style={sHdr}>Section Rationales</div>
                    {FLAG_SECTIONS.map((s) => result.section_rationales?.[s.id] && (
                      <div key={s.id} style={{ marginBottom: "14px" }}>
                        <div style={{ fontSize: "12px", fontWeight: "700", color: s.color, marginBottom: "5px" }}>{s.label}</div>
                        <div style={{ fontSize: "13px", color: "#444", lineHeight: "1.65", paddingLeft: "12px", borderLeft: `3px solid ${s.border}` }}>{result.section_rationales[s.id]}</div>
                      </div>
                    ))}
                  </div>
                  {result.clinician_notes && (
                    <div style={{ background: "#F0F6FF", border: "1px solid #B8D0F0", borderRadius: "10px", padding: "16px 20px" }}>
                      <div style={{ fontSize: "10px", color: "#2C5F8F", fontWeight: "700", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "8px" }}>👨‍⚕️ For NP / MD / DON Review</div>
                      <div style={{ fontSize: "13px", color: "#1A2E4A", lineHeight: "1.7" }}>{result.clinician_notes}</div>
                    </div>
                  )}
                  {ALL_FLAG_IDS.filter(id => ef(id).value === "yes").length > 0 && (
                    <div style={{ background: "#FEF0F0", border: "1px solid #F5C6C6", borderRadius: "10px", padding: "16px 20px" }}>
                      <div style={{ fontSize: "10px", color: "#9B2335", fontWeight: "700", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "10px" }}>🔴 Active YES Flags</div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5px" }}>
                        {ALL_FLAG_IDS.filter(id => ef(id).value === "yes").map(id => {
                          const fd = FLAG_SECTIONS.flatMap(s => s.flags).find(f => f.id === id);
                          return <div key={id} style={{ fontSize: "12px", color: "#9B2335", display: "flex", gap: "6px" }}><span>🔴</span>{fd?.label || id}</div>;
                        })}
                      </div>
                    </div>
                  )}
                  {result.information_gaps?.length > 0 && (
                    <div style={{ background: "#FFFBF0", border: "1px solid #F0D899", borderRadius: "10px", padding: "16px 20px" }}>
                      <div style={{ fontSize: "10px", color: "#B07800", fontWeight: "700", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "10px" }}>⚠️ Missing Information</div>
                      <ul style={{ margin: 0, paddingLeft: "18px" }}>
                        {result.information_gaps.map((g, i) => <li key={i} style={{ fontSize: "13px", color: "#5A4000", marginBottom: "5px", lineHeight: "1.5" }}>{g}</li>)}
                      </ul>
                    </div>
                  )}
                  <div style={{ background: "#EDE8E0", borderRadius: "8px", padding: "11px 16px", fontSize: "11px", color: "#888", textAlign: "center", lineHeight: "1.6" }}>
                    Decision support only. Cedar Oaks Training Guide 2025 criteria. Does not replace NP/MD/DON approval, utilization review, or final admission authority.
                  </div>
                  <button onClick={() => { setResult(null); setTab("intake"); setOverrides(Object.fromEntries(ALL_FLAG_IDS.map(id => [id, "auto"]))); }} style={{ background: "#7B4A2D", color: "#FFF", border: "none", borderRadius: "8px", padding: "10px 20px", fontSize: "13px", fontWeight: "700", cursor: "pointer", alignSelf: "flex-start", fontFamily: "inherit" }}>
                    ← Reset Review
                  </button>
                </>
              )}
            </div>
          )}
        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } } * { box-sizing: border-box; }`}</style>
      </div>
    </>
  );
}
